package progpoe2024;

import javax.swing.JOptionPane;
import java.util.Scanner;

public class PROGPOE2024 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Create variables to receive user input
        System.out.println("Welcome to Registration and Login System");
        System.out.println("----------------------------------------");

        System.out.println("Enter your username: ");
        String username = scanner.nextLine();

        System.out.println("Enter your password: ");
        String password = scanner.nextLine();

        System.out.println("Enter your first name: ");
        String firstName = scanner.nextLine();

        System.out.println("Enter your last name: ");
        String lastName = scanner.nextLine();

        Login login = new Login();

        String registrationMessage = login.registerUser(username, password);
        System.out.println(registrationMessage);

        if (registrationMessage.equals("Username and Password successfullfy captured")) {
            System.out.println("Enter your username to login: ");
            String enteredUsername = scanner.nextLine();

            System.out.println("Enter your password to login: ");
            String enteredPassword = scanner.nextLine();

            boolean isSuccessful = login.loginUser(username, enteredUsername, enteredPassword, password);
            System.out.println(login.returnLoginStatus(isSuccessful, firstName, lastName));
            
            if (isSuccessful) {
                JOptionPane.showMessageDialog(null, "Welcome to EasyKanban!");

                AddTask taskManager = new AddTask();
                while (true) {
                    int choice = taskManager.showMenu();

                    switch (choice) {
                        case 1:
                            taskManager.addTasks();
                            break;
                        case 2:
                            int option = taskManager.Options();
                            switch (option) {
                                case 1:
                                    JOptionPane.showMessageDialog(null, taskManager.display());
                                    break;
                                case 2:
                                    JOptionPane.showMessageDialog(null, taskManager.MaxDuration());
                                    break;
                                case 3:
                                    String searchName = JOptionPane.showInputDialog("Enter task name to search:");
                                    if (searchName != null && !searchName.trim().isEmpty()) {
                                        JOptionPane.showMessageDialog(null, taskManager.Search(searchName));
                                    } else {
                                        JOptionPane.showMessageDialog(null, "Task name cannot be empty.");
                                    }
                                    break;
                                case 4:
                                    String searchDeveloper = JOptionPane.showInputDialog("Enter developer name to search:");
                                    if (searchDeveloper != null && !searchDeveloper.trim().isEmpty()) {
                                        JOptionPane.showMessageDialog(null, taskManager.SearchDeveloperDetails(searchDeveloper));
                                    } else {
                                        JOptionPane.showMessageDialog(null, "Developer name cannot be empty.");
                                    }
                                    break;
                                case 5:
                                    String deleteTask = JOptionPane.showInputDialog("Enter task name to delete:");
                                    if (deleteTask != null && !deleteTask.trim().isEmpty()) {
                                        taskManager.Delete(deleteTask);
                                    } else {
                                        JOptionPane.showMessageDialog(null, "Task name cannot be empty.");
                                    }
                                    break;
                                case 6:
                                    JOptionPane.showMessageDialog(null, "Exiting application.");
                                    System.exit(0);
                                    break;
                                default:
                                    JOptionPane.showMessageDialog(null, "Invalid choice, please select from the menu.");  
                            }
                            break;
                        case 3:
                            JOptionPane.showMessageDialog(null, "Exiting application.");
                            System.exit(0);
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Invalid choice, please select from the menu.");  
                    }
                }
            }
        } else {
            // Display error message and terminate the program
            JOptionPane.showMessageDialog(null, registrationMessage);
        }

        scanner.close();
    }
}